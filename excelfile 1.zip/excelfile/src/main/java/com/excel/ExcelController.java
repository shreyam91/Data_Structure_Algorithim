package com.excel;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExcelController {
	public static void main(String[] args) {
        String inputFilePath = "mock_data.xlsx"; // input file path or name 

        ExcelDataSegregator segregator = new ExcelDataSegregator();
        segregator.processExcel(inputFilePath);
	
}}
	
	class ExcelDataSegregator {

		public void processExcel(String inputFilePath) {
	    	try (FileInputStream inputStream = new FileInputStream(new File(inputFilePath))) {
	    		Workbook workbook = new XSSFWorkbook(inputStream);
				Sheet sheet = workbook.getSheetAt(0); // data is in the first sheet


	            HashMap<String, List<Row>> statusData = new HashMap<>();

	            // Loop through each row in the sheet (skip header row)
	            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
	            	Row row = sheet.getRow(rowIndex);

	                int statusColumnIndex = 5;
					// Get the status value from the specified column
	                String status = row.getCell(statusColumnIndex).getStringCellValue();

	               
	                List<Row> statusRows = statusData.get(status);
	                if (statusRows == null) {
	                    statusRows = new ArrayList<>();
	                    statusData.put(status, statusRows);
	                }

	                // Add the status row to the status list
	                statusRows.add(row);
	            }

	            // Create a new workbook for the split data
	            XSSFWorkbook newWorkbook = new XSSFWorkbook();

	            // Loop through each status and create a new sheet with its data
	            for (HashMap.Entry<String, List<Row>> entry : statusData.entrySet()) {
	            	XSSFSheet newSheet = newWorkbook.createSheet(entry.getKey());


	                // Write status data to the new sheet (starting from row 1)
	                int targetRow = 1;
	                for (Row row : entry.getValue()) {
	                	
	                    newSheet.createRow(targetRow).copyRowFrom(row, new CellCopyPolicy());
	                    targetRow++;
	                }
	            }

	         // Write the split data to a new excel file
	            FileOutputStream outputStream = new FileOutputStream("data_status.xlsx");
	            newWorkbook.write(outputStream);
	            outputStream.close();
	         	System.out.println("Excel file split by status successfully!");
	    } catch (IOException e) {
			e.printStackTrace();
		}
//	        workbook.close();
	    	}
	}
	    	


